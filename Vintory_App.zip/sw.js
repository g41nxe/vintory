// Service Worker for PWA (basic offline support)
self.addEventListener('install', (e) => {
  console.log('[Service Worker] Install');
});

self.addEventListener('fetch', (e) => {
  // Basic pass-through for now, as we don't cache assets yet.
  e.respondWith(fetch(e.request));
});
